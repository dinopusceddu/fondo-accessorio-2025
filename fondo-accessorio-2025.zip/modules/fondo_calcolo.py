def calcola_fondo(dati):
    fondo_2016 = dati["fondo_2016"]
    dipendenti_2018 = dati["dipendenti_2018"]
    dipendenti_2025 = dati["dipendenti_2025"]
    spesa_tabellare_2023 = dati["spesa_tabellare_2023"]

    incremento_procapite = (dipendenti_2025 / dipendenti_2018) * fondo_2016
    limite_48 = 0.48 * spesa_tabellare_2023

    fondo_totale = min(incremento_procapite, limite_48)
    return {
        "fondo_calcolato": round(fondo_totale, 2),
        "limite_48": round(limite_48, 2),
        "incremento_procapite": round(incremento_procapite, 2)
    }
