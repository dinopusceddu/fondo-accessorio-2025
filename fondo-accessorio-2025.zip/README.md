# App Fondo Salario Accessorio 2025

Applicazione Streamlit per la costituzione, controllo e documentazione del fondo delle risorse decentrate degli enti locali.

## Come si usa
1. Carica i dati richiesti (fondo 2016, dipendenti, spesa personale, ecc.)
2. Verifica i vincoli normativi e contrattuali
3. Genera documenti automatici: relazioni, scheda fondo, bozza contratto

## Avvio locale
```bash
pip install -r requirements.txt
streamlit run app.py
```
