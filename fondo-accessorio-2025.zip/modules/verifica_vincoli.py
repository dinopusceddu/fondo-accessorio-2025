def verifica_vincoli(dati):
    risultati = {}
    risultati["tetto_2016"] = dati["fondo_calcolato"] <= dati["tetto_2016"]
    risultati["personale_vs_entrate"] = dati["spesa_personale"] < (dati["entrate_correnti"] * 0.30)
    risultati["equilibrio_bilancio"] = dati.get("equilibrio_bilancio", False)
    return risultati
