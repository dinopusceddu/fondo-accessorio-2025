from docxtpl import DocxTemplate
from io import BytesIO

def genera_relazioni(dati):
    tpl = DocxTemplate("templates/relazione_template.docx")
    tpl.render(dati)
    docx_io = BytesIO()
    tpl.save(docx_io)
    pdf_io = docx_io  # Per demo, conversione vera da aggiungere
    return docx_io, pdf_io
