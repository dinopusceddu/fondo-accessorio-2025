import json

def esporta_documenti(dati):
    with open("data/esempio_output.json", "w") as f:
        json.dump(dati, f, indent=2)
