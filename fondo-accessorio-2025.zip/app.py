import streamlit as st
import pandas as pd
from modules.fondo_calcolo import calcola_fondo
from modules.verifica_vincoli import verifica_vincoli
from modules.relazioni_generator import genera_relazioni
from modules.exporter import esporta_documenti

st.set_page_config(page_title="Fondo Salario Accessorio 2025", layout="wide")
st.title("Costituzione e Controllo Fondo Salario Accessorio 2025")

menu = st.sidebar.selectbox("Menu", ["Costituzione Fondo", "Controllo Vincoli", "Generazione Documenti"])

if menu == "Costituzione Fondo":
    st.header("1. Costituzione del Fondo")
    input_data = st.file_uploader("Carica dati in formato JSON", type="json")
    if input_data:
        dati = pd.read_json(input_data)
        risultato = calcola_fondo(dati)
        st.json(risultato)

elif menu == "Controllo Vincoli":
    st.header("2. Verifica dei vincoli normativi")
    dati = st.session_state.get("dati_fondo")
    if dati:
        verifica = verifica_vincoli(dati)
        st.write(verifica)
    else:
        st.warning("Carica prima i dati nella sezione 'Costituzione Fondo'.")

elif menu == "Generazione Documenti":
    st.header("3. Generazione documentazione")
    dati = st.session_state.get("dati_fondo")
    if dati:
        docx_file, pdf_file = genera_relazioni(dati)
        st.download_button("Scarica Relazione DOCX", docx_file, file_name="relazione.docx")
        st.download_button("Scarica Relazione PDF", pdf_file, file_name="relazione.pdf")
        esporta_documenti(dati)
    else:
        st.warning("Carica prima i dati nella sezione 'Costituzione Fondo'.")
